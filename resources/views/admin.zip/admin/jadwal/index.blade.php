@extends('layouts/app2')
@section('content')
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Kelola Data Jadwal</h3>
                    </div>
                    <!-- /.card-header -->
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->

                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Jadwal</h3>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        {{-- <a class="btn btn-success" href="{{ route('register')}}"> +Tambah User </a> --}}
                        <a class="btn btn-outline-primary" href="{{ route('jadwal.create')}}" style="width: 200px" >Tambah Jadwal</a>
                    </div>
                    <div class="card-body">
                        <table id="example1" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Tanggal Perform</th>
                                    <th>Tipe Perform</th>
                                    <th>Alamat</th>
                                    <th>Peyewa</th>
                                    <th>Hp</th>
                                    <th>Action</th>
                                </tr>
                            </thead>

                            <tbody>
                                @php
                                $i=1;
                                $x=1;
                            @endphp
                             @foreach ($data as $datajadwal)

                                <tr>
                                    <td><b>{{$i++}}<b></td>
                                    <td>{{ $datajadwal['tgl_perform']}}</td>
                                    <td>{{ $datajadwal['tipe']['tipe_perform']}}</td>
                                    <td>{{ $datajadwal['alamat']}}</td>
                                    <td>{{ $datajadwal['user']['name']}}</td>
                                    <td>{{ $datajadwal['hp']}}</td>
                                    {{-- <td>{{ $j->tipe->tipe_perform}}</td> --}}

                                    <td>
                                        <form action="{{ route('jadwal.delete', $datajadwal['id'])}}" method="post">
                                        <a class="btn btn-sm btn-warning" href="{{ route('jadwal.edit', $datajadwal['id'])}}">Edit</a>
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                        </form>
                                    </td>
                                </tr>

                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</section>

  @endsection
