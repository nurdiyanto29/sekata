@extends('layouts/app2')
@section('content')
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Kelola Tipe</h3>
                        </div>
                        <!-- /.card-header -->
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->

                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title"></h3>
                        </div>
                        <!-- /.card-header -->

                        <div class="card-body">
                            {{-- <a class="btn btn-success" href="{{ route('register')}}"> +Tambah User </a> --}}
                            <a class="btn btn-outline-primary" href="{{ route('tipe.create') }}"
                                style="width: 200px">Tambah Tipe</a>
                        </div>
                        <div class="card-body">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Tipe Perform</th>
                                        <th>Harga Sewa</th>
                                        <th>Cover</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    @php
                                        $i = 1;
                                        $x = 1;
                                    @endphp
                                    @foreach ($tipe as $t)
                                        <tr>
                                            <td><b>{{ $i++ }}<b></td>
                                            <td>{{ $t['tipe_perform'] }}</td>
                                            <td>{{ 'Rp.' . number_format($t['harga_sewa'], 2, ',', '.') }}</td>
                                            <td> <img src="{{ asset('tipe/' . $t['cover']) }}" style="height: 160px"
                                                    alt="Image"></td>

                                            <td>
                                                <form action="{{ route('tipe.delete', $t['id']) }}" method="post">
                                                    <a class="btn btn-sm btn-warning"
                                                        href="{{ route('tipe.edit', $t['id']) }}">Edit</a>
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                                </form>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
    </section>
@endsection
